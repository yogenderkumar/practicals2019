<!DOCTYPE html>
<html>
<head>
	<title>PALINDROM STRING</title>
</head>
<body>
	<?php

		$str = $_POST["str"];
		echo "string is $str<br><BR>";
		$str1 = strrev($str);

		if($str == $str1)
		{
			echo "yes it's a PALINDROM<br>";
		}

		else
		{
			echo "Oops! not a PALINDROM";
		}


	?>

</body>
</html>