<!DOCTYPE html>
<html>
<head>
	<title>FACTORIAL CALCULATION</title>
</head>
<body>
	<?php
		$num = $_POST["number"];
		echo "Number whose factorial will be calculated $num <br>";
		factorial($num);

		function factorial($num)
		{	
			$fact=1;
			for($i=1;$i<=$num;$i++)
			{
				$fact = $i*$fact;
			}
			echo "factorial: $fact";
		}

	?>
</body>
</html>