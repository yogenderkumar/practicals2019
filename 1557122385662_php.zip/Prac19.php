<!DOCTYPE html>
<html>
<head>
	<title>REPLACE THIS WITH THAT</title>
</head>
<body>
	<?php

		$str = $_POST["str"];
		echo "$str <br>";
		$new_str = preg_replace('/this/', 'that', $str,1);
		echo "$new_str";

	?>

</body>
</html>