<!DOCTYPE html>
<html>
<head>
	<title>FIBONACCI SERIES</title>
</head>
<body>
	<?php
		$num = $_POST["num"];

		for ($i=0; $i <= $num ; $i++)
		{ 
			echo fibonacci($i);
			echo " ";
		}

		function fibonacci($num)
		{
			if($num == 0)
			{
				return 0;
			}
			elseif ($num == 1) 
			{
				return 1;
			}
			else
			{
				return (fibonacci($num-1) + fibonacci($num-2));
			}
		}



	?>

</body>
</html>