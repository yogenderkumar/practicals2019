<!DOCTYPE html>
<html>
<head>
	<title>SEARCHING SUBSTRING</title>
</head>
<body>
	<?php
		$str = $_POST["str"];
		$str1 = $_POST["str1"];
		
		if(strpos($str,$str1)!== false)
		{
			echo "Substring is Present";
		}
		else
		{
			echo "Substring not Present";
		}


	?>

</body>
</html>	