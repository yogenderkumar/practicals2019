<!DOCTYPE html>
<html>
<head>
	<title>LOWERCASE STRING</title>
</head>
<body>
	<?php
		$str = array($_POST["str"]);

		foreach ($str as $check) 
		{
			if(ctype_lower($check))
			{
				echo "lowecase string <br>";
			}
			else
			{
				echo "not a lowecase string";
			}
		}

	?>

</body>
</html>