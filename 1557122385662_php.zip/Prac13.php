<!DOCTYPE html>
<html>
<head>
	<title>PATTERN</title>
</head>
<body>
	<?php
		$num = $_POST["num"];
		for ($i=0; $i<$num; $i++) 
		{ 
			for ($j=0; $j<= $i ; $j++) 
			{ 
				echo "* ";
			}
			echo "<br>";
		}

	?>

</body>
</html>