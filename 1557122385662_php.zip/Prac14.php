<!DOCTYPE html>
<html>
<head>
	<title>EMAIL VALIDATION</title>
</head>
<body>
	<?php
		$email = $_POST["eid"];
		if(filter_var($email, FILTER_VALIDATE_EMAIL))
		{
			echo "Valid email id <br>";

		}
		else
		{
			echo "Invalid email id";
		}
	?>

</body>
</html>