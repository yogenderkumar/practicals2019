<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
		$num = $_POST["num"];
		echo "Even no. upto $num are: <br>";
		for ($i=1; $i<=$num; $i++) 
		{ 
			if($i % 2 == 0)
			{
				echo "$i <br>";
			}
		}


	?>

</body>
</html>