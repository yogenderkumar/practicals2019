<!DOCTYPE html>
<html>
<head>
	<title>REVERSE STRING</title>
</head>
<body>
	<?php
		$str = $_POST["str"];
		echo "$str<br>";
		$new_str = strrev($str);
		echo "<br> String after reverse: $new_str";

	?>

</body>
</html>