<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php

if(isset($_POST["Languages"]))
{
    $lang=$_POST["Languages"];
    // echo $lang;
    switch($lang) 
    {
        case "GERMAN":
            echo "Hallo!!";
            break;
        case "SPANISH":
            echo "Hola!!";
            break;
        case "ENGLISH":
            echo "Hello!!";
            break;
        //default:
           // echo "no language selected";
    }
}
?>

</body>
</html>