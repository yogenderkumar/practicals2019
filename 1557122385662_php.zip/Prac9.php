<!DOCTYPE html>
<html>
<head>
	<title>SUM OF ODD NUMBERS</title>
</head>
<body>
	<?php
		$num = $_POST["num"];
		$sum = 0;
		for ($i=1; $i < $num ; $i++) 
		{ 
			
			if(($i%2)!= 0)
			{
				$sum = $sum+$i;
			}
		}
		echo "sum of odd numbers till $num : $sum";
	
	?>


</body>
</html>