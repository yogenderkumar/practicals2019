<!DOCTYPE html>
<html>
<head>
	<title>SORTING ARRAY</title>
</head>
<body>
	<?php

		$names =  array("Priyanka","Ishita","Alisha","Vandana","Manika","Niharika");
		$len = count($names);
		sort($names);

		for ($i=0; $i < $len; $i++) 
		{ 
			echo $names[$i]."<br>";
		}
	?>


</body>
</html>