<!DOCTYPE html>
<html>
<head>
	<title>TRIM WHITESPACES</title>
</head>
<body>
	<?php

		$str = $_POST["str"];
		echo "$str <br>";

		$new_str = preg_replace('/\s+/','',$str);
		echo "$new_str";
	?>

</body>
</html>