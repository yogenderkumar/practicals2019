<!DOCTYPE html>
<html>
<head>
	<title>SIGNUP STUDENT DATA</title>
</head>
<body>
<?php
require 'Prac10_conn.php';
$Name = $_POST["sname"];
$Rno = $_POST["rno"];
$Course = $_POST["course"];
$Username = $_POST["uname"];
$Password = $_POST["pass"];

$sql = "insert into student values('".$Name."','".$Rno."','".$Course."','".$Username."','".$Password."')";
$res = mysqli_query($con, $sql);
echo "Record Added";

?>
</body>
</html>