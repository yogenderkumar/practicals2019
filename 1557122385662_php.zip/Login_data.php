<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
</head>
<body>
	<?php
		require 'Prac10_conn.php';
		$UNAME = $_POST["uname1"];
		$PASS = $_POST["pass1"];
		$sql = "select count(*) as tuser FROM student where Username = '".$UNAME."' AND Password = '".$PASS."'";
		//$sql = "select Username, Password FROM student where Username = '".$UNAME."' AND Password = '".$PASS."'";
		$res = mysqli_query($con,$sql);
		$rows = mysqli_fetch_assoc($res);
		$count = $rows['tuser'];
		if($count>0)
		//if (mysqli_num_rows($res)>0)
		{
			echo "WELCOME TO STUDENT PORTAL!!!<br>";
		}
		else
		{
			echo "Username or Password doesnot EXIST!!!";
		}



	?>

</body>
</html>