<!DOCTYPE html>
<html>
<head>
	<title>BIRTHDAY COUNTDOWN</title>
</head>
<body>
	<?php
		$name = $_POST["str"];
		$bdate = $_POST["bdate"];
		$Curdate = date_create();
		//$currd = date_format($Curdate,"m-d-Y");
		$birthdate =  date_create($bdate);
		$diff = date_diff($Curdate,$birthdate);
		echo "Hey $name! <br>";
		echo $diff->format('%a days are left in your birthday!!!');

	?>
</body>
</html>