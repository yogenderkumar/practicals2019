<!DOCTYPE html>
<html>
<body>
<?php
	echo "Largest of 3 nos. <br><br>";
	$max;
	$x = $_POST["num1"];
	$y = $_POST["num2"];
	$z = $_POST["num3"];

	largest($x,$y,$z);

	function largest($a, $b, $c)
	{
		if($a>$b && $a>$c)
			$max = $a;
		elseif ($b>$a && $b>$c)
			$max = $b;
		else
			$max = $c;
		echo "Largest of three numbers is: $max";
	}


?>
</body>
</html>