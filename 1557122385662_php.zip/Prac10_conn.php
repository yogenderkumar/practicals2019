<?php

$host = "localhost";
$username = "root";
$pass="";
$db="student_info";

$con = mysqli_connect($host,$username,$pass,$db);

// Check connection
if (mysqli_connect_errno())
  {
  	echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


?> 