<!DOCTYPE html>
<html>
<head>
	<title>Prime/not prime</title>
</head>
<body>
	<?php
		$num = $_POST["num"];
		$temp = 0;
		for($i=1;$i<=$num;$i++)
		{
			if($num%$i==0)
			{
					$temp++;
			}
		}
		if($temp == 2)
		{
			echo "$num is PRIME";
		}
		else
		{
			echo "$num is NOT PRIME";
		}
	?>
</body>
</html>