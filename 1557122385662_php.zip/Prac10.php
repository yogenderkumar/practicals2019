<!DOCTYPE html>
<html>
<head>
	<title>STUDENT LOGIN</title>
</head>
<body>

<?php
	require 'Prac10_conn.php';
			if(isset($_POST['Submit']))
			{
				$Uname = $_POST["uname"];
				$Rno = $_POST["rno"];
				$Course = $_POST["course"];
				$sql = "insert into student values('".$Uname."','".$Rno."','".$Course."')";
				$res = mysqli_query($con,$sql);
				echo "Successfully ADDED";
	
			}
?>
<?php

		require 'Prac10_conn.php';
		$sql1 = "update student set Rollno = 17501 where Sname='Alisha'";
		$res = mysqli_query($con,$sql1);
		echo "Updated<br><br>";
?>

<?php
		require 'Prac10_conn.php';
		$sql2 = "SELECT Sname, Rollno, Course from student";
		$res = mysqli_query($con,$sql2);
		if(mysqli_num_rows($res)>0)
		{
			while($row = mysqli_fetch_assoc($res))
			{
				echo "Sname: ".$row["Sname"]."  Roll no.: " .$row["Rollno"]."  Course: ".$row["Course"];
				echo "<br>";
			}
		}
?>

</body>
</html>