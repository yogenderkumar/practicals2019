<!DOCTYPE html>
<html>
<head>
	<title>UNORDERED DISPLAY</title>
</head>
<body>
	<?php
		//$color1 = $_POST["c1"];
		//$color2 = $_POST["c2"];
		//$color3 = $_POST["c3"];

		$colors = array("white","green","red");
		rsort($colors);
		foreach ($colors as $x)
		{
			echo "$x ";
		}
		echo "<br><br>";
		sort($colors);

		echo "<ul>";
		foreach ($colors as $j) 
		{
			echo "<li> $j </li>";
		}
		echo "</ul>"


	?>


</body>
</html>