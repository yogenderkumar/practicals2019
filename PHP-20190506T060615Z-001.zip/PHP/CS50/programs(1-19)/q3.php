<html>
    <fieldset  >
        <legend><b> TO CHECK WHEATHER THE NUMBER IS PRIME OR NOT?</b></legend>
    <body>
        <form action="q3.php" method= "post">
       <b>Input Number: </b>    <input type="number" name="num1"><br><br>
         <input type="submit"> <br>  
        </form>
        
        <?php
        
        $a=$_POST["num1"];$counter=0;
        for($i=1;$i<=$a;$i++)
        {
            if($a%$i==0)
            {
                $counter++;
            }
        }
            if($counter==2)
            {
                echo "$a Number is Prime<br>";
            }
            else
            {
                echo "$a Number is not Prime";
            }
        ?>
    </body></fieldset>
</html>