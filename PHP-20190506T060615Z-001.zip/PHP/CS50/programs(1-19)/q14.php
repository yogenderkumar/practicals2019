<!DOCTYPE HTML>
<html>
    <body><fieldset>
        <style>
        .error {color: #FF0000;}
        .error1{color:blue;}
        </style>
        
                 <?php
           
            $email =""; $emailErr = "";
            if($_SERVER["REQUEST_METHOD"] == "POST")
            {
                if(empty($_POST["email"]))
                {
                    $emailErr = "Email is required ";
                }
                else
                {
                    $email = check($_POST["email"]);
                    if(!filter_var($email, FILTER_VALIDATE_EMAIL))
                    {
                        $emailErr="Invalid Email Format:";
                    }
                }
                
            }
            function check($data)
            {
                $data=trim($data);
                $data=stripslashes($data);
                $data=htmlspecialchars($data);
                return $data;
            }
            ?>
        
        <legend><h3>TO CHECK THAT EMAILS ARE VALID:</h3></legend>
        <p><span class="error"> <i><b>* Required field</b></i></span></p>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
             <span class="error1"<b>Enter Your EmailId:</b><input type="text" name="email" ></span>
            <span class="error">* <?php echo $emailErr;?></span><br><br><br>
            <input type="submit">
        </form>
       

            <?php
            echo $email;
            ?>
            
    </fieldset>
    </body>
</html>