<html>
    <fieldset  >
        <legend><b>SORT AN ARRAY:</b></legend>
    <body>
        <?php
        $numbers = array(1, 6, 3, 22, 41);
        sort($numbers);

        $arrlength = count($numbers);
        for($x = 0; $x < $arrlength; $x++) {
         echo $numbers[$x];
         print "<br>";
        }
        ?>
    </body></fieldset>
</html>