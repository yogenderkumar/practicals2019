<html>
    <fieldset  >
        <legend><b>PAGE DISPLAYS THE SUM OF N ODD NUMBERS:</b></legend>
    <body>
        <form action="q9.php" method= "post">
       <b>Input Number: </b>    <input type="number" name="num"><br><br>
         <input type="submit"> <br>  
        </form>
        
        <?php
        $sum=0;
        for($i=1;$i<=$_POST["num"];$i+=2)
        {
           $sum+=$i; 
        }
        echo "<b>Sum is $sum</b>"
      
        ?>
    </body></fieldset>
</html>