<html>
    <fieldset  >
        <legend><b>PAGE CHECKS STRING IS ALL LOWER CASE?</b></legend>
    <body>
        <form action="q5.php" method= "post">
       <b>Input String: </b>    <input type="text" name="str"><br><br>
         <input type="submit"> <br>  
        </form>
        
        <?php
        $a= $_POST["str"];
         if(ctype_lower($a))
         {
           echo "The String <b>$a </b> consists of all lower case<br>.";
         }
         else
            {
            echo "The String <b>$a </b> doesnot consists of all lower case<br>.";
             }
        ?>
    </body></fieldset>
</html>