<html>
    <head></head>
    <body>
        <fieldset style=width:200px;>
            <legend><b><i>Array of cars</i></b></legend>
         
            <?php
            $color = array("white","green","red");
            $a=count($color);
            for($j=0;$j<$a;$j++)
            {
                echo "$color[$j]    ,  ";
            }
                echo "<ul>";
                echo "<li>$color[1]</li>";
                echo "<li>$color[2]</li>";
                echo "<li>$color[0]</li>";
                echo "</ul>";
            ?>
        </fieldset>
    </body>
</html>