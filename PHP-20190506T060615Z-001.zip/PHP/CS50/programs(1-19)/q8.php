<html>
    <fieldset>
        <legend><b>REMOVES THE WHITEAPACE FROM THE STRING:</b></legend>
    <body>
        <form action="q8.php" method= "post">
            <p style="border:3px solid blue;color:red;font-size:40px;background-color:yellow;"><b><b>Input String:</b><input type="text" name="str"><br></b></p>
         <input type="submit"> <br>  
        </form>
        
        <?php
        $a=$_POST["str"];
        echo "<b>Your Output:</b><br>";
        echo str_replace(' ','',$a);
      
        ?>
    </body></fieldset>
</html>