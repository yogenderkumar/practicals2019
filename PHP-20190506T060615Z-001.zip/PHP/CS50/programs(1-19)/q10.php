<?php include('server.php');?>
<html>
    <fieldset style="width:400px;border-color:blue"; >
        <legend style="color:blue;margin-left:40%";><b><i>LOGIN PAGE</i></b></legend>
    <body>
        <form action="#" method= "post">
        <b style=color:red;;>USERNAME: </b>    <input style=background-color:pink; type="text" name="username" placeholder="Enter your name"><br><br>
        <b style=color:red;>PASSWORD: </b>    <input style=background-color:pink; type="password" name="password"placeholder="Password"><br><br>
        <input style="background-color:yellow;color:green;margin-left:40%;margin-right:auto"; type="submit" value="Submit"> <br>  
        </form>
        </fieldset>
        
        <?php
           /*echo "<br>";
           $a=$_POST["str"];
           $b=$_POST["pass"];
           echo "<b>Your Username is-></b> $a\n<br>";
           echo "<b>Your Password is-></b> $b\n";*/
           
        ?>
    </body>
</html>