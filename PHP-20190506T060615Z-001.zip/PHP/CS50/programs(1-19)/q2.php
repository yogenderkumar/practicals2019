<html>
    <fieldset  >
        <legend><b>FIND THE FACTORIAL OF A NUMBER</b></legend>
    <body>
        <form action="q2.php" method= "post">
       <b>Input Number: </b>    <input type="text" name="num1"><br><br>
         <input type="submit"> <br>  
        </form></fieldset>
        
        <?php
        $fact=1;
        echo "<br><b><i>The Factorial is:</i></b>";
        for($i=1;$i<=$_POST["num1"];$i++)
        { 
            $fact=$fact*$i;
        }
        echo $fact;
      
        ?>
    </body>
</html>