<html>
    <head></head>
    <body>
        <fieldset style=width:500px;>
            <legend style=color:red;><b><i><>To count the no.of days between curent day and Birthday:<></i></b></legend>
            <form action="q12.php" method="post">
                <b style=color:orange;>When is your birthday:</b>
                <input type="date" name="d1">
                <input style=color:blue; type="submit" value="send">
            </form>
            
            <?php
                if($_POST["d1"]>0)
                {
                    $target_days =strtotime($_POST["d1"]); //mktime(0,0,0,2,11,2019);// modify the birth day 12/31/2013
                    $today = time();
                    $diff_days = ($target_days - $today);
                    $days = (int)($diff_days/86400);
                    $a=$days+1;
                    print "Days left for next birthday: $a days!"."\n";
                }
                else
                {
                    print "<b><i>Plz. Enter a valid day.<i></b>";
                }
            ?>
        </fieldset>
    </body>
</html>