<!DOCTYPE html>
<html>
<head>
	<title>Practical 17</title>
</head>
<body>
	<h1>Practical 17</h1>


	<?php
		for ($i=0; $i <5 ; $i++) { 
			for ($j=0; $j <=$i ; $j++) { 
				echo "*";
			}
			echo "<br>";
		}

	?>

</body>
</html>