<html>
    <fieldset  >
        <legend><b>PAGE DISPLAYS THE REVERSE OF THGE PROVIDED STRING:</b></legend>
    <body>
        <form action="q4.php" method= "post">
       <b>Input String: </b>    <input type="text" name="str"><br><br>
         <input type="submit"> <br>  
        </form>
        
        <?php
        
       echo strrev($_POST["str"]);
      
        ?>
    </body></fieldset>
</html>