<html>
    <fieldset  >
        <legend><b>FIND THE LARGEST NUMBER</b></legend>
    <body>
        <form action="q1.php" method= "post">
       <b>First Number: </b>    <input type="text" name="num1"><br><br>
       <b>Second Number: </b>    <input type="text" name="num2"><br><br>
       <b>Third Number:</b>     <input type="text" name="num3"><br><br>
         <input type="submit"> <br>  
        </form></fieldset>
        
        <?php
        echo "<br><b><i>The Largest Number is:</i></b>";
        echo max($_POST["num1"],$_POST["num2"],$_POST["num3"]);
      
        ?>
    </body>
</html>