<html>
    <fieldset  >
        <legend><b>PAGE DISPLAYS WHEATHER THE STRING IS PALINDROME OR NOT:</b></legend>
    <body>
        <form action="q6.php" method= "post">
       <b>Input String: </b>    <input type="text" name="str"><br><br>
         <input type="submit"> <br>  
        </form>
        
        <?php
        
         $a= strrev($_POST["str"]);
         if($a==$_POST["str"])
         {
             echo "<b>PALINDROME</b>";
         }
         else
         {
             echo "<b>NOT PALINDROME</b>";
         }
      
        ?>
    </body></fieldset>
</html>