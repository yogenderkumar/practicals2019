<html>
    <h1>MONU WEBSITE</h1>
    <body><fieldset>
        
        <legend><b><i>PATTERN</i></b></legend>
        <form  action="q13.php" method="post">
            <b>INPUT NUMBER:</b><input type="number" name="num">
            <input type="submit">
        </form>
        <?php
        echo "<b>Your output:</b><br>";
        for($i=0;$i<$_POST["numl"];$i++)
        {
            for($j=0;$j<=$i;$j++)
            {
                echo "<b>*</b>";
            }
            echo "<br>";
        }
        ?>
    </fieldset>
    </body>
</html>