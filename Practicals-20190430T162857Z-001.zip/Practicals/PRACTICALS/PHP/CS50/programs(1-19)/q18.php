<html>
    <head>
      <h2 style=color:magenta;> Write a PHP program to print <i>Fibonacci series</i> using recursion.</h2>  
    </head>
    <body><fieldset style=width:50px;>
        <legend><i><b>Fibonacci Series</b></i></legend>
        <form action="q18.php" method="post">
           <span style=color:red;><b>Input position:</b></span><input type="number" name="num"><br>
           <input type="submit" value="Send">
        </form>
        
        <?php
        $a=$_POST["num"];
        function fibonacci($a)
        {
            if($a==0 )
            {
                return 0;
            }
            else if( $a==1)
            {
                return 1;
            }
            else
            {
                return (fibonacci($a-1) + fibonacci($a-2));
            }
        }
          echo "<b>OUTPUT: </b>";
                 for($i=0;$i<$a;$i++)
                 {
                    echo fibonacci($i);
                    echo " ";
                 }
        ?>
    </fieldset>
    </body>
</html>