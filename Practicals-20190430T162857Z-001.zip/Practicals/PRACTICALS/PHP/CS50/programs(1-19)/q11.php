<html>
    <fieldset  >
        <legend><b>PAGE CHECKS IF A CONTAINS ANOTHER STRING OR NOT</b></legend>
    <body>
        <form action="q11.php" method= "post">
       <b>Input 1st String: </b>    <input type="text" name="str1"><br><br>
       <b><i>Check the word in the above string:</i> </b>    <input type="text" name="str2"><br><br>
         <input type="submit"> <br>  
        </form>
        
        <?php
        $a= $_POST["str1"];
        $b= $_POST["str2"];
         if(strpos($a ,$b)) 
         {
           echo "The String <b>$a </b> consists  <b>$b</b word <br>.";
         }
         else
            {
             }
        ?>
    </body></fieldset>
</html>