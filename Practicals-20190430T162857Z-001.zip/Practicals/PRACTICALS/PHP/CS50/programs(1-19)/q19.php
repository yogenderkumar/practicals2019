<html>
    <body>
        <fieldset style=width:400px;>
            <legend style=color:red;><b>Replace the word of 1st Occurance:</b></legend>
            <form action="q19.php" method="post">
                <b>Input String:</b><input type="text" name="str">
                <input type="submit" value="Get">
            </form>
            
            <?php
            $a=$_POST["str"];
            echo preg_replace('/the/', 'That', $a, 1);
            ?>
        </fieldset>
    </body>
</html>