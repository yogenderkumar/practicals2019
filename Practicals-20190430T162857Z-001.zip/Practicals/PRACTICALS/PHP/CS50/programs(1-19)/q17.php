<!HTML DOC>
<html><head>
    <h3> Using switch case and dropdown list display a <i>Hello</i> message depending on the language selected in drop down list.</h3>
</head>
    <fieldset>
        <legend><b>LETS TRY THIS</b></legend>
        <body>
            <form action="q17.php" method="post">
                <b>Please select the language:</b>
            <select  name="submit">
                <br><option value="">select</option><br>
                <br><option value="Nameste">Hindi</option><br>
                <br><option value="Hello">English</option><br>
                <br><option value="French">French</option><br>
                <br><option value="G">German</option><br>
                <br><option value="i">Indonesian</option><br>
            </select>
            <input type="submit" value="send"><br>
            </form>
            <?php
            $a=$_POST["submit"];
            switch($a)
            {
                case "Nameste":
                    echo "<b>Nameste</b>";
                    break;
                case "Hello":
                    echo "<b>Hello</b>";
                    break;
                case "French":
                    echo "<b>Bonjour</b>";
                    break;
                case "G":
                    echo "<b>Hallo</b>";
                    break;
                case "i":
                    echo "<b>Halo</b>";
                    break;
                default:
                    echo "<b>Plz. select the appropriate language:</b>";
            }
            /*if(isset($_POST["submit"]));
            {
               $a =$_POST["submit"];  
            }
            echo "<b>Your Output:</b>";
            echo $a;
            
            */
            ?>
            
        
        </body>
    </fieldset>
</html>