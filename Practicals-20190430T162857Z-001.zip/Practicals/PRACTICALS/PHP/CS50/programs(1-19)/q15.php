<html>
    <fieldset  >
        <legend><b>PAGE DISPLAYS FIRST N EVEN NUMBERS:</b></legend>
    <body>
        <form action="q15.php" method= "post">
       <b>Input Number: </b>    <input type="number" name="num"><br><br>
         <input type="submit"> <br>  
        </form>
        
        <?php
        for($i=2;$i<=$_POST["num"];$i+=2)
        {
           echo "$i<br>"; 
        }
        
      
        ?>
    </body></fieldset>
</html>